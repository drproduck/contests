#include <bits/stdc++.h>

using namespace std;

const double EPS = 1e-8;
const int N = 10005;

double x[N], y[N], w[N];
double mx_x, mx_y, mn_x, mn_y;
int n;

int cmp(double u, double v) {
    if (fabs(u-v) < EPS) return 0;
    if (u-v < EPS) return -1;
    return 1;
}

double ok2(double X, double Y) {
    double res = 0;
    for (int i = 0; i < n; ++i)
        res += max(fabs(X-x[i]),fabs(Y-y[i]))*w[i];
    return res;
}

double ok(double X) {
    double L = mn_y, R = mx_y;
    for (int i = 0; i < 100; ++i) {
        double M1 = (R - L)/3 + L;
        double M2 = R - (R - L)/3;
        if (cmp(ok2(X,M1),ok2(X,M2)) <= 0) R = M2;
        else L = M1;
    }
    return ok2(X,L);
}

int main() {
	freopen("B-large.in","r",stdin);
	freopen("output.txt","w",stdout);
    int t; cin >> t; int te = t;
    while (t--) {
        cin >> n;
        mx_x = -10000000, mx_y = -10000000, mn_x = 10000000, mn_y = 10000000;
        for (int i = 0; i < n; ++i) {
            cin >> x[i] >> y[i] >> w[i];
            mx_x = max(mx_x,x[i]);
            mx_y = max(mx_y,y[i]);
            mn_x = min(mn_x,x[i]);
            mn_y = min(mn_y,y[i]);
        }
        double L = mn_x, R = mx_x;
        for (int i = 0; i < 100; ++i) {
            double M1 = (R - L)/3 + L;
            double M2 = R - (R - L)/3;
            if (cmp(ok(M1),ok(M2)) <= 0) R = M2;
            else L = M1;
        }
        cout << "Case #" << te-t << ": ";
        cout << fixed << setprecision(7) << ok(L) << endl;
    }
	return 0;
}
