#include <bits/stdc++.h>

using namespace std;

#define double long double

const int MAX_N = 100030;
double x[MAX_N],y[MAX_N],w[MAX_N];
int n;

double f(double xx,double yy){
  double ans = 0;
  for(int i=0;i<n;i++)
    ans += max(abs(x[i]-xx),abs(y[i]-yy)) * w[i];
  return ans;
}

const double dx[8] = {-1,-1,-1, 0, 0, 1, 1, 1};
const double dy[8] = {-1, 0, 1,-1, 1,-1, 0, 1};

bool new_point(double& xx,double& yy){
  double curr = f(xx,yy);
  bool update = false;
  for(double len = 1000 ; len > 1e-10 ; len /= 2){
    for(int k=0;k<8;k++){
      double next = f(xx+dx[k]*len,yy+dy[k]*len);
      if(next < curr){
	xx += dx[k]*len;
	yy += dy[k]*len;
	update = true;
      }
    }
    if(update) return true;
  }
  return false;
}

double do_case(){
  cin >> n;
  for(int i=0;i<n;i++)
    cin >> x[i] >> y[i] >> w[i];

  double xx = 0, yy = 0;
  while(new_point(xx,yy)) ;

  return f(xx,yy);
}

int main(){
  int T,C=1; cin >> T;
  cout << fixed << setprecision(10);
  while(T--)
    cout << "Case #" << C++ << ": " << do_case() << endl;
  return 0;
}
